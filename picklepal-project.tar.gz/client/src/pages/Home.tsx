import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent } from "@/components/ui/card";
import { Calendar, Trophy, Users } from "lucide-react";
import { Link } from "wouter";

export default function Home() {
  const { user } = useAuth();

  const actionCards = [
    {
      href: "/venues",
      icon: Calendar,
      title: "Book a Court",
      description: "Find and reserve courts near you",
      gradient: "from-primary/20 to-primary/5",
      iconBg: "bg-primary/20",
      iconColor: "text-primary",
    },
    {
      href: "/compete",
      icon: Trophy,
      title: "Compete",
      description: "Join tournaments and leagues",
      gradient: "from-amber-500/20 to-amber-500/5",
      iconBg: "bg-amber-500/20",
      iconColor: "text-amber-500",
    },
    {
      href: "/find-matches",
      icon: Users,
      title: "Find a Match",
      description: "Play with others in your area",
      gradient: "from-blue-500/20 to-blue-500/5",
      iconBg: "bg-blue-500/20",
      iconColor: "text-blue-500",
    },
  ];

  return (
    <div className="container mx-auto px-4 py-6 space-y-8">
      <div>
        <h1 className="text-3xl font-display font-bold text-foreground">
          Hi, {user?.firstName || "Player"}
        </h1>
        <p className="text-muted-foreground mt-1">What would you like to do today?</p>
      </div>

      <div className="grid gap-4">
        {actionCards.map((card) => (
          <Link key={card.href} href={card.href}>
            <Card 
              className="overflow-hidden hover-elevate cursor-pointer border-border/50"
              data-testid={`action-card-${card.title.toLowerCase().replace(/\s+/g, '-')}`}
            >
              <CardContent className={`p-6 bg-gradient-to-r ${card.gradient}`}>
                <div className="flex items-center gap-4">
                  <div className={`p-4 rounded-xl ${card.iconBg}`}>
                    <card.icon className={`w-8 h-8 ${card.iconColor}`} />
                  </div>
                  <div className="flex-1">
                    <h2 className="text-xl font-display font-bold">{card.title}</h2>
                    <p className="text-muted-foreground text-sm">{card.description}</p>
                  </div>
                  <div className="text-muted-foreground">
                    <svg 
                      className="w-6 h-6" 
                      fill="none" 
                      stroke="currentColor" 
                      viewBox="0 0 24 24"
                    >
                      <path 
                        strokeLinecap="round" 
                        strokeLinejoin="round" 
                        strokeWidth={2} 
                        d="M9 5l7 7-7 7" 
                      />
                    </svg>
                  </div>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
