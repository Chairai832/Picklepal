import { useVenues } from "@/hooks/use-venues";
import { VenueCard } from "@/components/VenueCard";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { 
  Search, SlidersHorizontal, X, MapPin, IndianRupee, Clock,
  Sun, Building2, Users, User, ChevronDown, ChevronUp, Navigation
} from "lucide-react";
import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import type { Court, Venue } from "@shared/schema";

type VenueWithCourts = Venue & { courts: Court[] };

const COURT_TYPES = [
  { value: "indoor", label: "Indoor", icon: Building2 },
  { value: "outdoor", label: "Outdoor", icon: Sun },
];

const COURT_SIZES = [
  { value: "singles", label: "Singles", icon: User },
  { value: "doubles", label: "Doubles", icon: Users },
];

const DURATIONS = [
  { value: "30", label: "30 min" },
  { value: "60", label: "1 hour" },
  { value: "90", label: "1.5 hours" },
  { value: "120", label: "2 hours" },
];

const AREAS = [
  { value: "indiranagar", label: "Indiranagar" },
  { value: "koramangala", label: "Koramangala" },
  { value: "whitefield", label: "Whitefield" },
  { value: "hsr", label: "HSR Layout" },
  { value: "jayanagar", label: "Jayanagar" },
];

const SORT_OPTIONS = [
  { value: "distance", label: "Distance: Nearest" },
  { value: "price_asc", label: "Price: Low to High" },
  { value: "price_desc", label: "Price: High to Low" },
  { value: "name_asc", label: "Name: A-Z" },
  { value: "name_desc", label: "Name: Z-A" },
];

export default function Venues() {
  const { data: venues, isLoading } = useVenues();
  const { data: courts } = useQuery<Court[]>({ queryKey: ["/api/courts"] });
  
  const [search, setSearch] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const [priceRange, setPriceRange] = useState([0, 2000]);
  const [selectedTypes, setSelectedTypes] = useState<string[]>([]);
  const [selectedSizes, setSelectedSizes] = useState<string[]>([]);
  const [selectedDurations, setSelectedDurations] = useState<string[]>([]);
  const [selectedAreas, setSelectedAreas] = useState<string[]>([]);
  const [sortBy, setSortBy] = useState("distance");

  const toggleFilter = (value: string, selected: string[], setSelected: (v: string[]) => void) => {
    if (selected.includes(value)) {
      setSelected(selected.filter(v => v !== value));
    } else {
      setSelected([...selected, value]);
    }
  };

  const clearFilters = () => {
    setSearch("");
    setPriceRange([0, 2000]);
    setSelectedTypes([]);
    setSelectedSizes([]);
    setSelectedDurations([]);
    setSelectedAreas([]);
    setSortBy("distance");
  };

  const hasActiveFilters = search || 
    priceRange[0] > 0 || 
    priceRange[1] < 2000 || 
    selectedTypes.length > 0 || 
    selectedSizes.length > 0 || 
    selectedDurations.length > 0 ||
    selectedAreas.length > 0;

  const venuesWithCourts = useMemo(() => {
    if (!venues || !courts) return [];
    return venues.map(venue => ({
      ...venue,
      courts: courts.filter(c => c.venueId === venue.id)
    })) as VenueWithCourts[];
  }, [venues, courts]);

  const filteredVenues = useMemo(() => {
    let result = venuesWithCourts;

    if (search) {
      const searchLower = search.toLowerCase();
      result = result.filter(v => 
        v.name.toLowerCase().includes(searchLower) || 
        v.location.toLowerCase().includes(searchLower) ||
        v.area?.toLowerCase().includes(searchLower)
      );
    }

    if (selectedTypes.length > 0) {
      result = result.filter(v => 
        v.courts.some(c => selectedTypes.includes(c.type))
      );
    }

    if (selectedSizes.length > 0) {
      result = result.filter(v => 
        v.courts.some(c => c.size && selectedSizes.includes(c.size))
      );
    }

    if (selectedAreas.length > 0) {
      result = result.filter(v => 
        selectedAreas.some(area => 
          v.area?.toLowerCase().includes(area.toLowerCase())
        )
      );
    }

    result = result.filter(v => {
      const minPrice = Math.min(...v.courts.map(c => c.pricePerHour || 0));
      return minPrice >= priceRange[0] && minPrice <= priceRange[1];
    });

    const areaOrder = ["indiranagar", "koramangala", "whitefield", "hsr", "jayanagar"];
    
    result.sort((a, b) => {
      const aMinPrice = Math.min(...a.courts.map(c => c.pricePerHour || 0));
      const bMinPrice = Math.min(...b.courts.map(c => c.pricePerHour || 0));
      const aAreaIndex = areaOrder.findIndex(area => a.area?.toLowerCase().includes(area));
      const bAreaIndex = areaOrder.findIndex(area => b.area?.toLowerCase().includes(area));
      
      switch (sortBy) {
        case "distance":
          return (aAreaIndex === -1 ? 999 : aAreaIndex) - (bAreaIndex === -1 ? 999 : bAreaIndex);
        case "price_asc":
          return aMinPrice - bMinPrice;
        case "price_desc":
          return bMinPrice - aMinPrice;
        case "name_asc":
          return a.name.localeCompare(b.name);
        case "name_desc":
          return b.name.localeCompare(a.name);
        default:
          return 0;
      }
    });

    return result;
  }, [venuesWithCourts, search, selectedTypes, selectedSizes, selectedAreas, priceRange, sortBy]);

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      <div className="space-y-2">
        <h1 className="text-3xl font-display font-bold" data-testid="text-page-title">Find a Court</h1>
        <p className="text-muted-foreground">Discover top-rated pickleball courts nearby.</p>
      </div>

      <div className="flex flex-col gap-4">
        <div className="flex flex-wrap gap-2">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <Input 
              placeholder="Search by name or location..." 
              className="pl-10 h-12 text-base rounded-xl bg-card"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              data-testid="input-search"
            />
          </div>
          <Button 
            variant={showFilters ? "default" : "outline"} 
            className="h-12 gap-2"
            onClick={() => setShowFilters(!showFilters)}
            data-testid="button-toggle-filters"
          >
            <SlidersHorizontal className="w-4 h-4" />
            Filters
            {hasActiveFilters && (
              <Badge variant="secondary" className="ml-1 h-5 w-5 p-0 flex items-center justify-center text-xs">
                {[selectedTypes.length, selectedSizes.length, 
                  selectedDurations.length, selectedAreas.length,
                  priceRange[0] > 0 || priceRange[1] < 2000 ? 1 : 0].reduce((a, b) => a + (b > 0 ? 1 : 0), 0)}
              </Badge>
            )}
            {showFilters ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </Button>
        </div>

        {showFilters && (
          <Card className="border-border/50" data-testid="card-filters">
            <CardContent className="p-4 space-y-6">
              <div className="flex flex-wrap items-center justify-between gap-4">
                <h3 className="font-semibold">Filter Courts</h3>
                {hasActiveFilters && (
                  <Button variant="ghost" size="sm" onClick={clearFilters} className="text-muted-foreground" data-testid="button-clear-filters">
                    <X className="w-4 h-4 mr-1" />
                    Clear all
                  </Button>
                )}
              </div>

              <div className="space-y-3">
                <Label className="text-sm font-medium">Sort By</Label>
                <div className="flex flex-wrap gap-2">
                  {SORT_OPTIONS.map(option => (
                    <Button
                      key={option.value}
                      variant={sortBy === option.value ? "default" : "outline"}
                      size="sm"
                      onClick={() => setSortBy(option.value)}
                      data-testid={`button-sort-${option.value}`}
                    >
                      {option.label}
                    </Button>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <Label className="text-sm font-medium flex items-center gap-2">
                  <IndianRupee className="w-4 h-4" />
                  Price Range (per hour)
                </Label>
                <div className="px-2">
                  <Slider
                    value={priceRange}
                    onValueChange={setPriceRange}
                    min={0}
                    max={2000}
                    step={100}
                    className="w-full"
                    data-testid="slider-price"
                  />
                  <div className="flex justify-between text-sm text-muted-foreground mt-2">
                    <span>₹{priceRange[0]}</span>
                    <span>₹{priceRange[1]}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <Label className="text-sm font-medium">Court Type</Label>
                <div className="flex flex-wrap gap-2">
                  {COURT_TYPES.map(type => (
                    <Button
                      key={type.value}
                      variant={selectedTypes.includes(type.value) ? "default" : "outline"}
                      size="sm"
                      onClick={() => toggleFilter(type.value, selectedTypes, setSelectedTypes)}
                      className="gap-2"
                      data-testid={`button-type-${type.value}`}
                    >
                      <type.icon className="w-4 h-4" />
                      {type.label}
                    </Button>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <Label className="text-sm font-medium">Court Size</Label>
                <div className="flex flex-wrap gap-2">
                  {COURT_SIZES.map(size => (
                    <Button
                      key={size.value}
                      variant={selectedSizes.includes(size.value) ? "default" : "outline"}
                      size="sm"
                      onClick={() => toggleFilter(size.value, selectedSizes, setSelectedSizes)}
                      className="gap-2"
                      data-testid={`button-size-${size.value}`}
                    >
                      <size.icon className="w-4 h-4" />
                      {size.label}
                    </Button>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <Label className="text-sm font-medium flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  Session Duration (Booking Preference)
                </Label>
                <p className="text-xs text-muted-foreground">Select your preferred session length for booking</p>
                <div className="flex flex-wrap gap-2">
                  {DURATIONS.map(duration => (
                    <Button
                      key={duration.value}
                      variant={selectedDurations.includes(duration.value) ? "default" : "outline"}
                      size="sm"
                      onClick={() => toggleFilter(duration.value, selectedDurations, setSelectedDurations)}
                      data-testid={`button-duration-${duration.value}`}
                    >
                      {duration.label}
                    </Button>
                  ))}
                </div>
              </div>

              <div className="space-y-3">
                <Label className="text-sm font-medium flex items-center gap-2">
                  <Navigation className="w-4 h-4" />
                  Area / Location
                </Label>
                <div className="flex flex-wrap gap-2">
                  {AREAS.map(area => (
                    <Button
                      key={area.value}
                      variant={selectedAreas.includes(area.value) ? "default" : "outline"}
                      size="sm"
                      onClick={() => toggleFilter(area.value, selectedAreas, setSelectedAreas)}
                      data-testid={`button-area-${area.value}`}
                    >
                      {area.label}
                    </Button>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        )}
      </div>

      {hasActiveFilters && (
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-sm text-muted-foreground">Active filters:</span>
          {selectedTypes.map(type => (
            <Badge key={type} variant="secondary" className="gap-1" data-testid={`badge-filter-type-${type}`}>
              {COURT_TYPES.find(t => t.value === type)?.label}
              <X className="w-3 h-3 cursor-pointer" onClick={() => toggleFilter(type, selectedTypes, setSelectedTypes)} />
            </Badge>
          ))}
          {selectedSizes.map(size => (
            <Badge key={size} variant="secondary" className="gap-1" data-testid={`badge-filter-size-${size}`}>
              {COURT_SIZES.find(s => s.value === size)?.label}
              <X className="w-3 h-3 cursor-pointer" onClick={() => toggleFilter(size, selectedSizes, setSelectedSizes)} />
            </Badge>
          ))}
          {selectedDurations.map(duration => (
            <Badge key={duration} variant="secondary" className="gap-1" data-testid={`badge-filter-duration-${duration}`}>
              {DURATIONS.find(d => d.value === duration)?.label}
              <X className="w-3 h-3 cursor-pointer" onClick={() => toggleFilter(duration, selectedDurations, setSelectedDurations)} />
            </Badge>
          ))}
          {selectedAreas.map(area => (
            <Badge key={area} variant="secondary" className="gap-1" data-testid={`badge-filter-area-${area}`}>
              {AREAS.find(a => a.value === area)?.label}
              <X className="w-3 h-3 cursor-pointer" onClick={() => toggleFilter(area, selectedAreas, setSelectedAreas)} />
            </Badge>
          ))}
          {(priceRange[0] > 0 || priceRange[1] < 2000) && (
            <Badge variant="secondary" className="gap-1" data-testid="badge-filter-price">
              ₹{priceRange[0]} - ₹{priceRange[1]}
              <X className="w-3 h-3 cursor-pointer" onClick={() => setPriceRange([0, 2000])} />
            </Badge>
          )}
        </div>
      )}

      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground" data-testid="text-results-count">
          {filteredVenues.length} venue{filteredVenues.length !== 1 ? 's' : ''} found
        </p>
      </div>

      {isLoading ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3, 4].map(i => (
            <div key={i} className="space-y-3">
              <Skeleton className="h-48 rounded-2xl" />
              <Skeleton className="h-4 w-2/3" />
              <Skeleton className="h-4 w-1/3" />
            </div>
          ))}
        </div>
      ) : filteredVenues.length === 0 ? (
        <Card className="p-12 text-center" data-testid="card-no-results">
          <MapPin className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
          <h3 className="font-semibold text-lg mb-2">No venues found</h3>
          <p className="text-muted-foreground mb-4">Try adjusting your filters or search terms.</p>
          {hasActiveFilters && (
            <Button variant="outline" onClick={clearFilters} data-testid="button-clear-filters-empty">
              Clear all filters
            </Button>
          )}
        </Card>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVenues.map(venue => (
            <VenueCard key={venue.id} venue={venue} />
          ))}
        </div>
      )}
    </div>
  );
}
