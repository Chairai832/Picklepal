import { useState, useEffect } from "react";
import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/hooks/use-auth";
import { ThumbsUp, ThumbsDown, Check, ArrowLeft, Trophy } from "lucide-react";

interface MatchPlayer {
  id: string;
  name: string;
  team: string;
}

interface MatchDetail {
  id: number;
  title: string;
  status: string;
  competitive: boolean;
  feedbackDeadline: number;
  hostName: string;
  courtName: string;
  venueName: string;
  city: string;
  area: string;
  startsAt: string;
  players: MatchPlayer[];
}

type VoteType = "higher" | "correct" | "lower";

export default function RatePlayers() {
  const { id } = useParams<{ id: string }>();
  const matchId = Number(id);
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();

  const [votes, setVotes] = useState<Record<string, VoteType>>({});
  const [submitted, setSubmitted] = useState(false);

  const { data: match, isLoading } = useQuery<MatchDetail>({
    queryKey: ["/api/matches", matchId],
    queryFn: async () => {
      const matches = await fetch("/api/matches").then(r => r.json());
      return matches.find((m: MatchDetail) => m.id === matchId);
    },
    enabled: !!matchId,
  });

  const submitMutation = useMutation({
    mutationFn: async (voteData: { aboutUserId: string; vote: VoteType }[]) => {
      return apiRequest("POST", `/api/matches/${matchId}/feedback`, { votes: voteData });
    },
    onSuccess: (data: any) => {
      setSubmitted(true);
      queryClient.invalidateQueries({ queryKey: ["/api/matches"] });
      
      if (data.finalized) {
        toast({
          title: "Match finalized",
          description: "All players submitted feedback. Ratings updated!",
        });
      } else {
        toast({
          title: "Feedback submitted",
          description: "Waiting for other players to submit their ratings.",
        });
      }
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-6">
        <Card>
          <CardContent className="p-8 text-center">
            Loading match details...
          </CardContent>
        </Card>
      </div>
    );
  }

  if (!match) {
    return (
      <div className="container mx-auto px-4 py-6">
        <Card>
          <CardContent className="p-8 text-center">
            <p className="text-muted-foreground">Match not found</p>
            <Button variant="outline" onClick={() => setLocation("/matches")} className="mt-4">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Matches
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (match.status !== "awaiting_feedback") {
    return (
      <div className="container mx-auto px-4 py-6">
        <Card>
          <CardContent className="p-8 text-center">
            <Trophy className="w-12 h-12 mx-auto mb-4 text-primary" />
            <h2 className="text-xl font-semibold mb-2">
              {match.status === "finalized" ? "Match Finalized" : "Feedback Not Available"}
            </h2>
            <p className="text-muted-foreground mb-4">
              {match.status === "finalized" 
                ? "This match has been completed and ratings have been updated."
                : "This match is not ready for feedback yet."}
            </p>
            <Button variant="outline" onClick={() => setLocation("/matches")}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Matches
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const otherPlayers = match.players.filter(p => p.id !== user?.id);
  const teamA = match.players.filter(p => p.team === "A");
  const teamB = match.players.filter(p => p.team === "B");

  const handleVote = (playerId: string, vote: VoteType) => {
    setVotes(prev => ({ ...prev, [playerId]: vote }));
  };

  const handleSubmit = () => {
    const voteData = Object.entries(votes).map(([aboutUserId, vote]) => ({
      aboutUserId,
      vote,
    }));
    submitMutation.mutate(voteData);
  };

  const allVoted = otherPlayers.every(p => votes[p.id]);

  const deadlineDate = match.feedbackDeadline ? new Date(match.feedbackDeadline) : null;
  const timeRemaining = deadlineDate ? Math.max(0, deadlineDate.getTime() - Date.now()) : 0;
  const hoursRemaining = Math.floor(timeRemaining / (1000 * 60 * 60));
  const minutesRemaining = Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60));

  if (submitted) {
    return (
      <div className="container mx-auto px-4 py-6">
        <Card>
          <CardContent className="p-8 text-center">
            <Check className="w-12 h-12 mx-auto mb-4 text-green-500" />
            <h2 className="text-xl font-semibold mb-2">Feedback Submitted</h2>
            <p className="text-muted-foreground mb-4">
              Thank you for rating your opponents. Ratings will update once all players submit feedback or the deadline passes.
            </p>
            <Button variant="outline" onClick={() => setLocation("/matches")}>
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Matches
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-6 pb-24 space-y-6">
      <Button variant="ghost" onClick={() => setLocation("/matches")} className="mb-2">
        <ArrowLeft className="w-4 h-4 mr-2" />
        Back to Matches
      </Button>

      <Card>
        <CardHeader>
          <CardTitle>Rate Players - {match.title}</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="text-sm text-muted-foreground">
            <p>{match.venueName} • {match.courtName}</p>
            <p>{new Date(match.startsAt).toLocaleString()}</p>
            {deadlineDate && (
              <p className="mt-2 text-orange-600">
                Deadline: {hoursRemaining}h {minutesRemaining}m remaining
              </p>
            )}
          </div>

          <div className="grid grid-cols-2 gap-4 text-sm">
            <div>
              <p className="font-medium">Team A</p>
              <p className="text-muted-foreground">{teamA.map(p => p.name).join(", ") || "—"}</p>
            </div>
            <div>
              <p className="font-medium">Team B</p>
              <p className="text-muted-foreground">{teamB.map(p => p.name).join(", ") || "—"}</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">How did these players perform?</CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <p className="text-sm text-muted-foreground">
            Rate each player relative to their displayed skill level. Your feedback helps calibrate ratings.
          </p>

          {otherPlayers.map((player) => (
            <div key={player.id} className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="font-medium">{player.name}</p>
                  <p className="text-sm text-muted-foreground">Team {player.team}</p>
                </div>
              </div>
              
              <div className="flex gap-2">
                <Button
                  variant={votes[player.id] === "higher" ? "default" : "outline"}
                  size="sm"
                  onClick={() => handleVote(player.id, "higher")}
                  className="flex-1"
                  data-testid={`vote-higher-${player.id}`}
                >
                  <ThumbsUp className="w-4 h-4 mr-1" />
                  Higher
                </Button>
                <Button
                  variant={votes[player.id] === "correct" ? "default" : "outline"}
                  size="sm"
                  onClick={() => handleVote(player.id, "correct")}
                  className="flex-1"
                  data-testid={`vote-correct-${player.id}`}
                >
                  <Check className="w-4 h-4 mr-1" />
                  Correct
                </Button>
                <Button
                  variant={votes[player.id] === "lower" ? "default" : "outline"}
                  size="sm"
                  onClick={() => handleVote(player.id, "lower")}
                  className="flex-1"
                  data-testid={`vote-lower-${player.id}`}
                >
                  <ThumbsDown className="w-4 h-4 mr-1" />
                  Lower
                </Button>
              </div>
            </div>
          ))}

          <Button 
            onClick={handleSubmit} 
            disabled={!allVoted || submitMutation.isPending}
            className="w-full"
            data-testid="submit-feedback"
          >
            {submitMutation.isPending ? "Submitting..." : "Submit Feedback"}
          </Button>

          {!allVoted && (
            <p className="text-sm text-center text-muted-foreground">
              Please rate all players before submitting
            </p>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
