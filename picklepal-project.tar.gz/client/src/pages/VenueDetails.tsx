import { useVenue } from "@/hooks/use-venues";
import { useRoute } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Info, ArrowLeft } from "lucide-react";
import { Link } from "wouter";
import { BookingDialog } from "@/components/BookingDialog";

export default function VenueDetails() {
  const [, params] = useRoute("/venues/:id");
  const id = parseInt(params?.id || "0");
  const { data: venue, isLoading } = useVenue(id);

  if (isLoading) {
    return (
      <div className="container mx-auto px-4 py-6 space-y-6">
        <Skeleton className="h-64 w-full rounded-2xl" />
        <div className="space-y-4">
          <Skeleton className="h-8 w-2/3" />
          <Skeleton className="h-4 w-1/3" />
          <Skeleton className="h-32 w-full" />
        </div>
      </div>
    );
  }

  if (!venue) return <div>Venue not found</div>;

  const image = venue.imageUrl || "https://images.unsplash.com/photo-1626244422258-293d254b9f04?q=80&w=1200&auto=format&fit=crop";

  return (
    <div className="pb-20">
      {/* Hero Image */}
      <div className="relative h-[300px] md:h-[400px] w-full">
         {/* Pickleball court hero */}
        <img src={image} alt={venue.name} className="w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
        <Link href="/venues" className="absolute top-6 left-4 md:left-8 bg-background/50 backdrop-blur-md p-2 rounded-full hover:bg-background transition-colors">
          <ArrowLeft className="w-6 h-6" />
        </Link>
      </div>

      <div className="container mx-auto px-4 -mt-20 relative z-10">
        <div className="bg-card rounded-3xl p-6 shadow-xl border border-border">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
            <div>
              <h1 className="font-display font-bold text-3xl mb-2">{venue.name}</h1>
              <div className="flex items-center text-muted-foreground">
                <MapPin className="w-4 h-4 mr-1 text-primary" />
                {venue.location}
              </div>
            </div>
            <div className="flex gap-2">
              <Badge variant="secondary" className="text-sm px-3 py-1">{venue.courts.length} Courts</Badge>
            </div>
          </div>

          <p className="text-muted-foreground leading-relaxed mb-8">
            {venue.description || "A premier pickleball destination featuring professional-grade courts and amenities for players of all levels."}
          </p>

          <h2 className="font-display font-bold text-xl mb-4">Available Courts</h2>
          <div className="grid md:grid-cols-2 gap-4">
            {venue.courts.map(court => (
              <div key={court.id} className="border border-border rounded-xl p-4 flex justify-between items-center hover:border-primary/50 transition-colors">
                <div>
                  <h3 className="font-bold">{court.name}</h3>
                  <div className="text-xs text-muted-foreground uppercase tracking-wider font-semibold mt-1">
                    {court.type} • {court.surface || 'Hard'} Surface
                  </div>
                </div>
                <BookingDialog courtId={court.id} courtName={court.name}>
                  <Button size="sm">Book</Button>
                </BookingDialog>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
