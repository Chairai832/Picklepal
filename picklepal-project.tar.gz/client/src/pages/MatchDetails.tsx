import { useMatches, useJoinMatch, useLeaveMatch, useCompleteMatch, useSetTeams } from "@/hooks/use-matches";
import { useAuth } from "@/hooks/use-auth";
import { useRoute, Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { MapPin, Clock, Calendar, ArrowLeft, Loader2, Share2, Trophy, MessageCircle, Users } from "lucide-react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";

function generateWhatsAppMessage(match: any) {
  const when = format(new Date(match.date), "PPpp");
  const openSpots = Math.max(0, (match.maxPlayers || 4) - (match.players?.length || 0));
  const teamA = (match.players || []).filter((p: any) => p.team === "A").map((p: any) => p.user?.firstName || p.name).join(", ") || "—";
  const teamB = (match.players || []).filter((p: any) => p.team === "B").map((p: any) => p.user?.firstName || p.name).join(", ") || "—";

  return [
    `Pickleball Match`,
    ``,
    `${match.court?.venue?.city || ""} - ${match.court?.venue?.name || ""} - ${match.court?.name || ""}`,
    `${when}`,
    `Skill: Level ${match.levelMin}-${match.levelMax}`,
    `Open spots: ${openSpots}/${match.maxPlayers || 4}`,
    ``,
    `Team A: ${teamA}`,
    `Team B: ${teamB}`,
    ``,
    `Join the match in PicklePal!`,
  ].join("\n");
}

export default function MatchDetails() {
  const [, params] = useRoute("/matches/:id");
  const id = parseInt(params?.id || "0");
  const { data: matches, isLoading } = useMatches();
  const { user } = useAuth();
  const { mutate: joinMatch, isPending: isJoining } = useJoinMatch();
  const { mutate: leaveMatch, isPending: isLeaving } = useLeaveMatch();
  const { mutate: completeMatch, isPending: isCompleting } = useCompleteMatch();
  const { mutate: setTeams, isPending: isSettingTeams } = useSetTeams();
  const { toast } = useToast();
  const [, navigate] = useLocation();

  const match = matches?.find(m => m.id === id);

  if (isLoading) return <div className="p-8"><Skeleton className="h-96 w-full rounded-3xl" /></div>;
  if (!match) return <div className="p-8">Match not found</div>;

  const userId = user?.id;
  const isJoined = match.players.some((p: any) => p.id === userId || p.userId === userId);
  const isFull = match.players.length >= (match.maxPlayers || 4);
  const isCreator = match.creatorId === userId;
  const teamA = match.players.filter((p: any) => p.team === "A");
  const teamB = match.players.filter((p: any) => p.team === "B");
  const hasTeams = teamA.length > 0 || teamB.length > 0;

  const handleJoin = () => {
    joinMatch({ matchId: match.id }, {
      onSuccess: () => toast({ title: "Joined!", description: "See you on the court!" }),
      onError: (err) => toast({ title: "Error", description: err.message, variant: "destructive" })
    });
  };

  const handleLeave = () => {
    leaveMatch({ matchId: match.id }, {
      onSuccess: () => toast({ title: "Left match", description: "You have been removed from the match." }),
      onError: (err) => toast({ title: "Error", description: err.message, variant: "destructive" })
    });
  };

  const handleSetTeams = () => {
    const playerIds = match.players.map((p: any) => p.id);
    if (playerIds.length < 4) {
      toast({ title: "Need 4 players", description: "Wait for more players to join", variant: "destructive" });
      return;
    }
    setTeams({ 
      matchId: match.id, 
      teamA: [playerIds[0], playerIds[1]], 
      teamB: [playerIds[2], playerIds[3]] 
    }, {
      onSuccess: () => toast({ title: "Teams set!" }),
      onError: (err) => toast({ title: "Error", description: err.message, variant: "destructive" })
    });
  };

  const handleComplete = (winnerTeam: "A" | "B" | "tie") => {
    completeMatch({ matchId: match.id, winnerTeam }, {
      onSuccess: () => {
        toast({ title: "Match completed!", description: "Rate your opponents now." });
        navigate(`/rate/${match.id}`);
      },
      onError: (err) => toast({ title: "Error", description: err.message, variant: "destructive" })
    });
  };

  const handleWhatsAppShare = async () => {
    const msg = generateWhatsAppMessage(match);
    try {
      await navigator.clipboard.writeText(msg);
      toast({ title: "Copied!", description: "WhatsApp invite copied to clipboard" });
    } catch {
      toast({ title: "Copy failed", variant: "destructive" });
    }
  };

  return (
    <div className="container mx-auto px-4 py-6 max-w-4xl">
      <Link href="/matches" className="inline-flex items-center text-muted-foreground hover:text-foreground mb-6 transition-colors">
        <ArrowLeft className="w-4 h-4 mr-1" /> Back to matches
      </Link>

      <div className="grid md:grid-cols-3 gap-8">
        {/* Left Column: Match Info */}
        <div className="md:col-span-2 space-y-6">
          <div>
            <div className="flex gap-2 mb-3">
              <Badge variant="outline" className="border-primary text-primary bg-primary/5">
                Level {match.levelMin}-{match.levelMax}
              </Badge>
              <Badge variant={isFull ? "secondary" : "default"}>
                {isFull ? "Full" : "Open Spots"}
              </Badge>
            </div>
            <h1 className="text-3xl md:text-4xl font-display font-bold mb-2">
              Match at {match.court.venue.name}
            </h1>
            <p className="text-muted-foreground">Hosted by {match.creator.firstName}</p>
          </div>

          <div className="bg-card border border-border rounded-2xl p-6 space-y-4 shadow-sm">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                <Calendar className="w-6 h-6" />
              </div>
              <div>
                <div className="font-semibold">Date</div>
                <div className="text-muted-foreground">{format(new Date(match.date), "EEEE, MMMM d, yyyy")}</div>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                <Clock className="w-6 h-6" />
              </div>
              <div>
                <div className="font-semibold">Time</div>
                <div className="text-muted-foreground">{format(new Date(match.date), "h:mm a")} ({match.duration} min)</div>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center text-primary">
                <MapPin className="w-6 h-6" />
              </div>
              <div>
                <div className="font-semibold">Location</div>
                <div className="text-muted-foreground">{match.court.venue.name} • {match.court.name}</div>
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-display font-bold text-xl mb-4">Teams ({match.players.length}/{match.maxPlayers})</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-primary/5 rounded-xl p-4 border border-primary/20">
                <div className="flex items-center gap-2 mb-3">
                  <Users className="w-4 h-4 text-primary" />
                  <span className="font-semibold text-sm">Team A</span>
                </div>
                <div className="space-y-2">
                  {teamA.length > 0 ? teamA.map((player: any) => (
                    <div key={player.id} className="flex items-center gap-2">
                      <Avatar className="w-8 h-8">
                        <AvatarImage src={player.user?.profileImageUrl || undefined} />
                        <AvatarFallback className="text-xs">{player.user?.firstName?.[0] || player.name?.[0]}</AvatarFallback>
                      </Avatar>
                      <span className="text-sm">{player.user?.firstName || player.name}</span>
                    </div>
                  )) : (
                    <div className="text-sm text-muted-foreground">Waiting for players...</div>
                  )}
                </div>
              </div>
              
              <div className="bg-muted/50 rounded-xl p-4 border border-border">
                <div className="flex items-center gap-2 mb-3">
                  <Users className="w-4 h-4" />
                  <span className="font-semibold text-sm">Team B</span>
                </div>
                <div className="space-y-2">
                  {teamB.length > 0 ? teamB.map((player: any) => (
                    <div key={player.id} className="flex items-center gap-2">
                      <Avatar className="w-8 h-8">
                        <AvatarImage src={player.user?.profileImageUrl || undefined} />
                        <AvatarFallback className="text-xs">{player.user?.firstName?.[0] || player.name?.[0]}</AvatarFallback>
                      </Avatar>
                      <span className="text-sm">{player.user?.firstName || player.name}</span>
                    </div>
                  )) : (
                    <div className="text-sm text-muted-foreground">Waiting for players...</div>
                  )}
                </div>
              </div>
            </div>

            {!hasTeams && match.players.length > 0 && (
              <div className="mt-4 space-y-2">
                <h4 className="font-medium text-sm text-muted-foreground">Unassigned Players</h4>
                <div className="flex flex-wrap gap-2">
                  {match.players.map((player: any) => (
                    <div key={player.id} className="flex items-center gap-2 p-2 rounded-lg bg-card border border-border">
                      <Avatar className="w-6 h-6">
                        <AvatarImage src={player.user?.profileImageUrl || undefined} />
                        <AvatarFallback className="text-xs">{player.user?.firstName?.[0]}</AvatarFallback>
                      </Avatar>
                      <span className="text-sm">{player.user?.firstName}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Right Column: Actions */}
        <div className="md:col-span-1">
          <div className="bg-card border border-border rounded-2xl p-6 sticky top-24 shadow-lg shadow-black/5 space-y-3">
            <h3 className="font-display font-bold text-lg mb-4">Match Actions</h3>
            
            {match.status === "scheduled" && (
              <>
                {isJoined ? (
                  <Button 
                    variant="destructive" 
                    className="w-full" 
                    onClick={handleLeave}
                    disabled={isLeaving}
                  >
                    {isLeaving ? <Loader2 className="w-4 h-4 animate-spin mr-2"/> : "Leave Match"}
                  </Button>
                ) : (
                  <Button 
                    className="w-full font-bold text-lg h-12 shadow-lg shadow-primary/20" 
                    onClick={handleJoin}
                    disabled={isJoining || isFull}
                  >
                    {isJoining ? <Loader2 className="w-4 h-4 animate-spin mr-2"/> : isFull ? "Match Full" : "Join Match"}
                  </Button>
                )}
              </>
            )}

            {isCreator && match.status === "scheduled" && isFull && !hasTeams && (
              <Button 
                variant="secondary" 
                className="w-full"
                onClick={handleSetTeams}
                disabled={isSettingTeams}
              >
                {isSettingTeams ? <Loader2 className="w-4 h-4 animate-spin mr-2"/> : <><Users className="w-4 h-4 mr-2" /> Set Teams</>}
              </Button>
            )}

            {isCreator && match.status === "scheduled" && hasTeams && (
              <div className="space-y-2">
                <p className="text-sm text-muted-foreground text-center">Who won?</p>
                <div className="grid grid-cols-3 gap-2">
                  <Button 
                    size="sm"
                    onClick={() => handleComplete("A")}
                    disabled={isCompleting}
                  >
                    <Trophy className="w-4 h-4 mr-1" /> Team A
                  </Button>
                  <Button 
                    variant="secondary"
                    size="sm"
                    onClick={() => handleComplete("tie")}
                    disabled={isCompleting}
                  >
                    Tie
                  </Button>
                  <Button 
                    size="sm"
                    onClick={() => handleComplete("B")}
                    disabled={isCompleting}
                  >
                    Team B <Trophy className="w-4 h-4 ml-1" />
                  </Button>
                </div>
              </div>
            )}

            {match.status === "awaiting_feedback" && (
              <Button 
                className="w-full"
                onClick={() => navigate(`/rate/${match.id}`)}
              >
                <Trophy className="w-4 h-4 mr-2" /> Rate Players
              </Button>
            )}

            {match.status === "finalized" && (
              <Badge variant="secondary" className="w-full justify-center py-2">
                Match Finalized
              </Badge>
            )}
            
            <Button variant="outline" className="w-full" onClick={handleWhatsAppShare}>
              <MessageCircle className="w-4 h-4 mr-2" /> Copy WhatsApp Invite
            </Button>
            
            <Button variant="ghost" className="w-full" onClick={() => {
              navigator.clipboard.writeText(window.location.href);
              toast({ title: "Link copied!" });
            }}>
              <Share2 className="w-4 h-4 mr-2" /> Share Link
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
