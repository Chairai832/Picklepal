import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ChevronLeft } from "lucide-react";

export default function TermsOfUse() {
  const [, navigate] = useLocation();

  return (
    <div className="container mx-auto px-4 py-6 pb-24 max-w-lg">
      <div className="flex items-center gap-3 mb-6">
        <Button variant="ghost" size="icon" onClick={() => navigate("/settings")} data-testid="button-back">
          <ChevronLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-2xl font-display font-bold">Terms of Use</h1>
      </div>

      <div className="prose prose-sm dark:prose-invert max-w-none">
        <p className="text-muted-foreground">Last updated: February 2026</p>

        <h2 className="text-lg font-semibold mt-6">1. Acceptance of Terms</h2>
        <p className="text-muted-foreground">
          By accessing or using PicklePal, you agree to be bound by these Terms of Use and our Privacy Policy. If you do not agree to these terms, please do not use our services.
        </p>

        <h2 className="text-lg font-semibold mt-6">2. Use of Services</h2>
        <p className="text-muted-foreground">
          PicklePal provides a platform for pickleball players to discover courts, book playing time, organize matches, and connect with other players. You agree to use our services only for lawful purposes.
        </p>

        <h2 className="text-lg font-semibold mt-6">3. User Accounts</h2>
        <p className="text-muted-foreground">
          You are responsible for maintaining the confidentiality of your account and for all activities that occur under your account. You must notify us immediately of any unauthorized use.
        </p>

        <h2 className="text-lg font-semibold mt-6">4. Bookings and Payments</h2>
        <p className="text-muted-foreground">
          Court bookings are subject to availability and venue policies. Cancellation policies are set by individual venues. Payment processing is handled securely through our payment partners.
        </p>

        <h2 className="text-lg font-semibold mt-6">5. Community Guidelines</h2>
        <p className="text-muted-foreground">
          Users must treat other members with respect. Harassment, discrimination, or abusive behavior will result in account suspension or termination.
        </p>

        <h2 className="text-lg font-semibold mt-6">6. Limitation of Liability</h2>
        <p className="text-muted-foreground">
          PicklePal is not responsible for injuries, disputes, or damages arising from court bookings or matches organized through our platform.
        </p>

        <h2 className="text-lg font-semibold mt-6">7. Contact Us</h2>
        <p className="text-muted-foreground">
          If you have questions about these Terms of Use, please contact us at legal@picklepal.app
        </p>
      </div>
    </div>
  );
}
