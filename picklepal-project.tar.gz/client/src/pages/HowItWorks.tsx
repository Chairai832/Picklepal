import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  ChevronLeft, ChevronRight, Settings, CreditCard, Users, Trophy, 
  GraduationCap, Gift, Smartphone
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const helpTopics = [
  {
    title: "App & Settings",
    description: "How to use the app and customize your settings",
    icon: Settings,
    content: "Navigate through the app using the bottom tabs. Access Settings from your Profile page using the menu icon (3 lines). Customize your preferences including privacy, notifications, and account settings."
  },
  {
    title: "Payments",
    description: "Payment methods, refunds, and transaction history",
    icon: CreditCard,
    content: "Add payment methods in Settings > Your Payments. View transaction history for all your bookings. Refunds are processed according to each venue's cancellation policy."
  },
  {
    title: "Communities",
    description: "Join groups, create matches, and connect with players",
    icon: Users,
    content: "Join matches from the 'Find Matches' tab. Create your own matches and share via WhatsApp. Follow other players and build your pickleball community."
  },
  {
    title: "Level & Results",
    description: "How ratings work and tracking your progress",
    icon: Trophy,
    content: "Your rating is calculated based on match outcomes against opponents of varying skill levels. Rating reliability increases as you play more matches. Complete matches and provide feedback to update ratings."
  },
  {
    title: "Learn & Compete",
    description: "Find classes, tournaments, and improve your game",
    icon: GraduationCap,
    content: "Browse venues for classes and coaching sessions. Join competitive matches to improve your rating. Look out for tournaments and competitions in your area."
  },
  {
    title: "Subscription & Offers",
    description: "Premium features and special deals",
    icon: Gift,
    content: "PicklePal is currently free to use! Watch for special offers and promotions from venues in your area. Premium features coming soon."
  },
];

export default function HowItWorks() {
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const handleTopicClick = (topic: typeof helpTopics[0]) => {
    toast({
      title: topic.title,
      description: topic.content,
    });
  };

  return (
    <div className="container mx-auto px-4 py-6 pb-24 max-w-lg">
      <div className="flex items-center gap-3 mb-6">
        <Button variant="ghost" size="icon" onClick={() => navigate("/settings")} data-testid="button-back">
          <ChevronLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-2xl font-display font-bold">How the App Works</h1>
      </div>

      <div className="mb-6">
        <Card className="bg-primary/5 border-primary/20">
          <CardContent className="flex items-center gap-4 p-4">
            <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center">
              <Smartphone className="w-6 h-6 text-primary" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold">Welcome to PicklePal!</h3>
              <p className="text-sm text-muted-foreground">
                Find courts, join matches, and connect with players in your area
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="space-y-3">
        {helpTopics.map((topic) => (
          <div 
            key={topic.title}
            className="flex items-center justify-between p-4 bg-card border border-border rounded-xl hover-elevate cursor-pointer"
            onClick={() => handleTopicClick(topic)}
            data-testid={`help-topic-${topic.title.toLowerCase().replace(/\s+/g, '-')}`}
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-muted flex items-center justify-center">
                <topic.icon className="w-5 h-5 text-muted-foreground" />
              </div>
              <div>
                <div className="font-medium">{topic.title}</div>
                <p className="text-sm text-muted-foreground">{topic.description}</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-muted-foreground" />
          </div>
        ))}
      </div>
    </div>
  );
}
