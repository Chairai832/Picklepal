import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { useLocation, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  ChevronLeft, ChevronRight, Trophy, GraduationCap, Users, Heart, Building2 
} from "lucide-react";

type RecentMatch = {
  id: number;
  title: string;
  startsAt: string;
  city: string;
  venueName: string;
  courtName: string;
  team: string;
  competitive: boolean;
  outcome: string;
};

export default function UserActivity() {
  const { user } = useAuth();
  const [, navigate] = useLocation();

  const { data: myMatchesData } = useQuery<{ 
    stats: { wins: number; losses: number; ties: number; total: number };
    recentMatches: RecentMatch[];
  }>({
    queryKey: ["/api/me/matches"],
    enabled: !!user?.id,
  });

  const matches = myMatchesData?.recentMatches || [];

  return (
    <div className="container mx-auto px-4 py-6 pb-24 max-w-lg">
      <div className="flex items-center gap-3 mb-6">
        <Button variant="ghost" size="icon" onClick={() => navigate("/settings")} data-testid="button-back">
          <ChevronLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-2xl font-display font-bold">Your Activity</h1>
      </div>

      <Tabs defaultValue="matches" className="w-full">
        <TabsList className="w-full grid grid-cols-5 mb-6">
          <TabsTrigger value="matches" className="text-xs" data-testid="tab-matches">
            <Trophy className="w-4 h-4" />
          </TabsTrigger>
          <TabsTrigger value="classes" className="text-xs" data-testid="tab-classes">
            <GraduationCap className="w-4 h-4" />
          </TabsTrigger>
          <TabsTrigger value="competitions" className="text-xs" data-testid="tab-competitions">
            <Trophy className="w-4 h-4" />
          </TabsTrigger>
          <TabsTrigger value="groups" className="text-xs" data-testid="tab-groups">
            <Users className="w-4 h-4" />
          </TabsTrigger>
          <TabsTrigger value="favourites" className="text-xs" data-testid="tab-favourites">
            <Heart className="w-4 h-4" />
          </TabsTrigger>
        </TabsList>

        <TabsContent value="matches" className="space-y-4">
          <h3 className="font-semibold flex items-center gap-2">
            <Trophy className="w-4 h-4 text-primary" />
            Matches
          </h3>
          {matches.length === 0 ? (
            <div className="text-center py-12 bg-muted/30 rounded-xl">
              <Trophy className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
              <p className="text-muted-foreground">No matches yet</p>
              <Button asChild className="mt-4">
                <Link href="/find-matches">Find Matches</Link>
              </Button>
            </div>
          ) : (
            <div className="space-y-3">
              {matches.map((match) => (
                <Link key={match.id} href={`/matches/${match.id}`}>
                  <div className="flex items-center justify-between p-4 bg-card border border-border rounded-xl hover-elevate cursor-pointer">
                    <div className="flex-1">
                      <div className="font-medium">{match.title}</div>
                      <div className="text-sm text-muted-foreground">
                        {match.venueName} • {new Date(match.startsAt).toLocaleDateString()}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge 
                        variant={match.outcome === "win" ? "default" : match.outcome === "loss" ? "destructive" : "secondary"}
                      >
                        {match.outcome?.toUpperCase() || "PENDING"}
                      </Badge>
                      <ChevronRight className="w-4 h-4 text-muted-foreground" />
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="classes" className="space-y-4">
          <h3 className="font-semibold flex items-center gap-2">
            <GraduationCap className="w-4 h-4 text-primary" />
            Classes
          </h3>
          <div className="text-center py-12 bg-muted/30 rounded-xl">
            <GraduationCap className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
            <p className="text-muted-foreground">No classes attended yet</p>
            <p className="text-sm text-muted-foreground mt-1">Classes feature coming soon</p>
          </div>
        </TabsContent>

        <TabsContent value="competitions" className="space-y-4">
          <h3 className="font-semibold flex items-center gap-2">
            <Trophy className="w-4 h-4 text-primary" />
            Competitions
          </h3>
          <div className="text-center py-12 bg-muted/30 rounded-xl">
            <Trophy className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
            <p className="text-muted-foreground">No competitions yet</p>
            <p className="text-sm text-muted-foreground mt-1">Competitions feature coming soon</p>
          </div>
        </TabsContent>

        <TabsContent value="groups" className="space-y-4">
          <h3 className="font-semibold flex items-center gap-2">
            <Users className="w-4 h-4 text-primary" />
            Groups
          </h3>
          <div className="text-center py-12 bg-muted/30 rounded-xl">
            <Users className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
            <p className="text-muted-foreground">No groups joined yet</p>
            <Button asChild className="mt-4">
              <Link href="/matches">Browse Community</Link>
            </Button>
          </div>
        </TabsContent>

        <TabsContent value="favourites" className="space-y-4">
          <h3 className="font-semibold flex items-center gap-2">
            <Heart className="w-4 h-4 text-primary" />
            Favourite Clubs
          </h3>
          <div className="text-center py-12 bg-muted/30 rounded-xl">
            <Building2 className="w-12 h-12 mx-auto text-muted-foreground mb-3" />
            <p className="text-muted-foreground">No favourite clubs yet</p>
            <Button asChild className="mt-4">
              <Link href="/venues">Browse Venues</Link>
            </Button>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
