import { useState } from "react";
import { useLocation } from "wouter";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { ChevronLeft, ChevronRight, Trophy, Target } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface OnboardingAnswers {
  pickleballExperience: string;
  playingDuration: string;
  playFrequency: string;
  racquetSports: string[];
  racquetYears: string;
  highestLevel: string;
  rallyConfidence: string;
  serveConsistency: string;
  netComfort: string;
  speedDefense: string;
  strategyUnderstanding: string;
  competitiveHistory: string;
  winRate: string;
  selfAssessment: string;
}

const initialAnswers: OnboardingAnswers = {
  pickleballExperience: "",
  playingDuration: "",
  playFrequency: "",
  racquetSports: [],
  racquetYears: "",
  highestLevel: "",
  rallyConfidence: "",
  serveConsistency: "",
  netComfort: "",
  speedDefense: "",
  strategyUnderstanding: "",
  competitiveHistory: "",
  winRate: "",
  selfAssessment: "",
};

const steps = [
  { title: "Pickleball Experience" },
  { title: "Racquet Sports Background" },
  { title: "Skill Assessment" },
  { title: "Competitive History" },
];

function calculateRating(answers: OnboardingAnswers): number {
  let score = 0;
  let maxScore = 0;

  const scoreMap: Record<string, Record<string, number>> = {
    pickleballExperience: { never: 0, few_times: 1, regularly: 2, competitive: 3 },
    playingDuration: { starting: 0, less_3_months: 1, three_to_12_months: 2, one_to_3_years: 3, more_3_years: 4 },
    playFrequency: { rarely: 0, monthly: 1, weekly: 2, multiple_weekly: 3, daily: 4 },
    racquetYears: { none: 0, less_1_year: 1, one_to_3_years: 2, three_to_7_years: 3, more_7_years: 4 },
    highestLevel: { casual: 0, club: 1, competitive: 2, state_national: 3 },
    rallyConfidence: { struggle: 0, few_shots: 1, consistent: 2, under_pressure: 3 },
    serveConsistency: { not_yet: 0, sometimes: 1, mostly: 2, always_variety: 3 },
    netComfort: { stay_back: 0, somewhat: 1, often: 2, strength: 3 },
    speedDefense: { no: 0, occasionally: 1, most_time: 2, confidently: 3 },
    strategyUnderstanding: { not_yet: 0, basic: 1, strong: 2, advanced: 3 },
    competitiveHistory: { never: 0, friendly: 1, local: 2, ranked: 3 },
    winRate: { rarely: 0, sometimes: 1, half: 2, usually: 3, almost_always: 4 },
    selfAssessment: { brand_new: 0, social: 1, competitive_rec: 2, advanced: 3, serious: 4 },
  };

  for (const [key, value] of Object.entries(answers)) {
    if (key === "racquetSports") continue;
    const map = scoreMap[key];
    if (map && value) {
      score += map[value] || 0;
      maxScore += Math.max(...Object.values(map));
    }
  }

  if (answers.racquetSports.length > 0) {
    score += Math.min(answers.racquetSports.length, 3);
    maxScore += 3;
  }

  const percentage = maxScore > 0 ? score / maxScore : 0;
  const rating = 1 + percentage * 6;
  return Math.round(rating * 10) / 10;
}

export default function Onboarding() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [currentStep, setCurrentStep] = useState(0);
  const [answers, setAnswers] = useState<OnboardingAnswers>(initialAnswers);

  const saveOnboardingMutation = useMutation({
    mutationFn: async (data: { rating: number }) => {
      return apiRequest("POST", "/api/profile/onboarding", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profile"] });
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({
        title: "Welcome to PicklePal!",
        description: "Your profile is set up and ready to go.",
      });
      navigate("/");
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save your profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const isStepValid = (): boolean => {
    switch (currentStep) {
      case 0:
        return !!(answers.pickleballExperience && answers.playingDuration && answers.playFrequency);
      case 1:
        return !!(answers.racquetYears && answers.highestLevel);
      case 2:
        return !!(answers.rallyConfidence && answers.serveConsistency && answers.netComfort && answers.speedDefense && answers.strategyUnderstanding);
      case 3:
        return !!(answers.competitiveHistory && answers.winRate && answers.selfAssessment);
      default:
        return false;
    }
  };

  const handleNext = () => {
    if (!isStepValid()) {
      toast({
        title: "Please complete all questions",
        description: "Answer all questions before proceeding.",
        variant: "destructive",
      });
      return;
    }
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      const rating = calculateRating(answers);
      saveOnboardingMutation.mutate({ rating });
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
    }
  };

  const updateAnswer = (key: keyof OnboardingAnswers, value: string | string[]) => {
    setAnswers({ ...answers, [key]: value });
  };

  const toggleRacquetSport = (sport: string) => {
    const current = answers.racquetSports;
    if (current.includes(sport)) {
      updateAnswer("racquetSports", current.filter((s) => s !== sport));
    } else {
      updateAnswer("racquetSports", [...current, sport]);
    }
  };

  const progress = ((currentStep + 1) / steps.length) * 100;

  const renderStep = () => {
    switch (currentStep) {
      case 0:
        return (
          <div className="space-y-6">
            <div className="space-y-4">
              <Label className="text-base font-medium">Have you played pickleball before?</Label>
              <RadioGroup value={answers.pickleballExperience} onValueChange={(v) => updateAnswer("pickleballExperience", v)} data-testid="radio-pickleball-experience">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="never" id="exp-never" />
                  <Label htmlFor="exp-never">Never</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="few_times" id="exp-few" />
                  <Label htmlFor="exp-few">A few times</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="regularly" id="exp-regular" />
                  <Label htmlFor="exp-regular">Regularly (weekly)</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="competitive" id="exp-comp" />
                  <Label htmlFor="exp-comp">Competitive/tournaments</Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-4">
              <Label className="text-base font-medium">How long have you been playing?</Label>
              <RadioGroup value={answers.playingDuration} onValueChange={(v) => updateAnswer("playingDuration", v)} data-testid="radio-playing-duration">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="starting" id="dur-start" />
                  <Label htmlFor="dur-start">Just starting</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="less_3_months" id="dur-3m" />
                  <Label htmlFor="dur-3m">Less than 3 months</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="three_to_12_months" id="dur-12m" />
                  <Label htmlFor="dur-12m">3–12 months</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="one_to_3_years" id="dur-3y" />
                  <Label htmlFor="dur-3y">1–3 years</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="more_3_years" id="dur-more" />
                  <Label htmlFor="dur-more">3+ years</Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-4">
              <Label className="text-base font-medium">How often do you currently play?</Label>
              <RadioGroup value={answers.playFrequency} onValueChange={(v) => updateAnswer("playFrequency", v)} data-testid="radio-play-frequency">
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="rarely" id="freq-rarely" />
                  <Label htmlFor="freq-rarely">First time / rarely</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="monthly" id="freq-monthly" />
                  <Label htmlFor="freq-monthly">1–2 times a month</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="weekly" id="freq-weekly" />
                  <Label htmlFor="freq-weekly">Weekly</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="multiple_weekly" id="freq-multi" />
                  <Label htmlFor="freq-multi">2–4 times per week</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="daily" id="freq-daily" />
                  <Label htmlFor="freq-daily">Almost daily</Label>
                </div>
              </RadioGroup>
            </div>
          </div>
        );

      case 1:
        return (
          <div className="space-y-6">
            <div className="space-y-4">
              <Label className="text-base font-medium">Have you played other racquet sports?</Label>
              <p className="text-sm text-muted-foreground">Select all that apply</p>
              <div className="space-y-2">
                {["Tennis", "Badminton", "Padel", "Squash", "Table Tennis"].map((sport) => (
                  <div key={sport} className="flex items-center space-x-2">
                    <Checkbox
                      id={`sport-${sport}`}
                      checked={answers.racquetSports.includes(sport)}
                      onCheckedChange={() => toggleRacquetSport(sport)}
                      data-testid={`checkbox-sport-${sport.toLowerCase().replace(' ', '-')}`}
                    />
                    <Label htmlFor={`sport-${sport}`}>{sport}</Label>
                  </div>
                ))}
              </div>
            </div>

            <div className="space-y-4">
              <Label className="text-base font-medium">Years of racquet sports experience?</Label>
              <RadioGroup value={answers.racquetYears} onValueChange={(v) => updateAnswer("racquetYears", v)}>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="none" id="ry-none" />
                  <Label htmlFor="ry-none">None</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="less_1_year" id="ry-1" />
                  <Label htmlFor="ry-1">Less than 1 year</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="one_to_3_years" id="ry-3" />
                  <Label htmlFor="ry-3">1–3 years</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="three_to_7_years" id="ry-7" />
                  <Label htmlFor="ry-7">3–7 years</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="more_7_years" id="ry-more" />
                  <Label htmlFor="ry-more">7+ years</Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-4">
              <Label className="text-base font-medium">Highest level in any racquet sport?</Label>
              <RadioGroup value={answers.highestLevel} onValueChange={(v) => updateAnswer("highestLevel", v)}>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="casual" id="lv-casual" />
                  <Label htmlFor="lv-casual">Casual only</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="club" id="lv-club" />
                  <Label htmlFor="lv-club">Club/intermediate</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="competitive" id="lv-comp" />
                  <Label htmlFor="lv-comp">Competitive league</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="state_national" id="lv-state" />
                  <Label htmlFor="lv-state">State/national level</Label>
                </div>
              </RadioGroup>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-6">
            <div className="space-y-4">
              <Label className="text-base font-medium">How confident are you with basic rallying?</Label>
              <RadioGroup value={answers.rallyConfidence} onValueChange={(v) => updateAnswer("rallyConfidence", v)}>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="struggle" id="rally-struggle" />
                  <Label htmlFor="rally-struggle">I struggle to keep the ball in play</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="few_shots" id="rally-few" />
                  <Label htmlFor="rally-few">I can rally a few shots</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="consistent" id="rally-consistent" />
                  <Label htmlFor="rally-consistent">I can rally consistently</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="under_pressure" id="rally-pressure" />
                  <Label htmlFor="rally-pressure">I can sustain long rallies under pressure</Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-4">
              <Label className="text-base font-medium">Can you serve consistently into the correct box?</Label>
              <RadioGroup value={answers.serveConsistency} onValueChange={(v) => updateAnswer("serveConsistency", v)}>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="not_yet" id="serve-not" />
                  <Label htmlFor="serve-not">Not yet</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="sometimes" id="serve-sometimes" />
                  <Label htmlFor="serve-sometimes">Sometimes</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="mostly" id="serve-mostly" />
                  <Label htmlFor="serve-mostly">Mostly yes</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="always_variety" id="serve-always" />
                  <Label htmlFor="serve-always">Always, with variety</Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-4">
              <Label className="text-base font-medium">Are you comfortable playing at the net?</Label>
              <RadioGroup value={answers.netComfort} onValueChange={(v) => updateAnswer("netComfort", v)}>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="stay_back" id="net-back" />
                  <Label htmlFor="net-back">No, I stay back</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="somewhat" id="net-somewhat" />
                  <Label htmlFor="net-somewhat">Somewhat</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="often" id="net-often" />
                  <Label htmlFor="net-often">Yes, I play net often</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="strength" id="net-strength" />
                  <Label htmlFor="net-strength">Yes, net play is a strength</Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-4">
              <Label className="text-base font-medium">Can you defend against fast shots (speed-ups)?</Label>
              <RadioGroup value={answers.speedDefense} onValueChange={(v) => updateAnswer("speedDefense", v)}>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="no" id="speed-no" />
                  <Label htmlFor="speed-no">No</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="occasionally" id="speed-occ" />
                  <Label htmlFor="speed-occ">Occasionally</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="most_time" id="speed-most" />
                  <Label htmlFor="speed-most">Yes, most of the time</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="confidently" id="speed-conf" />
                  <Label htmlFor="speed-conf">Yes, confidently</Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-4">
              <Label className="text-base font-medium">Do you understand pickleball strategy?</Label>
              <RadioGroup value={answers.strategyUnderstanding} onValueChange={(v) => updateAnswer("strategyUnderstanding", v)}>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="not_yet" id="strat-not" />
                  <Label htmlFor="strat-not">Not yet</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="basic" id="strat-basic" />
                  <Label htmlFor="strat-basic">Basic understanding</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="strong" id="strat-strong" />
                  <Label htmlFor="strat-strong">Strong understanding</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="advanced" id="strat-advanced" />
                  <Label htmlFor="strat-advanced">Advanced tactical play</Label>
                </div>
              </RadioGroup>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="space-y-4">
              <Label className="text-base font-medium">Have you played competitive matches or tournaments?</Label>
              <RadioGroup value={answers.competitiveHistory} onValueChange={(v) => updateAnswer("competitiveHistory", v)}>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="never" id="comp-never" />
                  <Label htmlFor="comp-never">Never</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="friendly" id="comp-friendly" />
                  <Label htmlFor="comp-friendly">Friendly competitive games only</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="local" id="comp-local" />
                  <Label htmlFor="comp-local">Local tournaments</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="ranked" id="comp-ranked" />
                  <Label htmlFor="comp-ranked">Ranked/state competitions</Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-4">
              <Label className="text-base font-medium">How often do you win against players at your level?</Label>
              <RadioGroup value={answers.winRate} onValueChange={(v) => updateAnswer("winRate", v)}>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="rarely" id="win-rarely" />
                  <Label htmlFor="win-rarely">Rarely</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="sometimes" id="win-sometimes" />
                  <Label htmlFor="win-sometimes">Sometimes</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="half" id="win-half" />
                  <Label htmlFor="win-half">About half</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="usually" id="win-usually" />
                  <Label htmlFor="win-usually">Usually</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="almost_always" id="win-almost" />
                  <Label htmlFor="win-almost">Almost always</Label>
                </div>
              </RadioGroup>
            </div>

            <div className="space-y-4">
              <Label className="text-base font-medium">Which statement describes you best?</Label>
              <RadioGroup value={answers.selfAssessment} onValueChange={(v) => updateAnswer("selfAssessment", v)}>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="brand_new" id="self-new" />
                  <Label htmlFor="self-new">I am brand new to pickleball</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="social" id="self-social" />
                  <Label htmlFor="self-social">I can play socially and enjoy rallies</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="competitive_rec" id="self-comp-rec" />
                  <Label htmlFor="self-comp-rec">I can play competitive recreational matches</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="advanced" id="self-advanced" />
                  <Label htmlFor="self-advanced">I play advanced, fast-paced doubles</Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="serious" id="self-serious" />
                  <Label htmlFor="self-serious">I compete seriously in tournaments</Label>
                </div>
              </RadioGroup>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  const calculatedRating = calculateRating(answers);

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <div className="container mx-auto px-4 py-6 max-w-lg flex-1 flex flex-col">
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <h1 className="text-xl font-display font-bold">Tell us about yourself</h1>
            <span className="text-sm text-muted-foreground">
              Step {currentStep + 1} of {steps.length}
            </span>
          </div>
          <Progress value={progress} className="h-2" />
        </div>

        <Card className="flex-1 mb-6">
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                {currentStep === 3 ? (
                  <Trophy className="w-5 h-5 text-primary" />
                ) : (
                  <Target className="w-5 h-5 text-primary" />
                )}
              </div>
              <div>
                <h2 className="font-semibold">{steps[currentStep].title}</h2>
                <p className="text-sm text-muted-foreground">
                  {currentStep === 0 && "Your experience with pickleball"}
                  {currentStep === 1 && "Other racquet sports you've played"}
                  {currentStep === 2 && "Your current skill level"}
                  {currentStep === 3 && "Your competitive experience"}
                </p>
              </div>
            </div>

            <div className="overflow-y-auto max-h-[calc(100vh-350px)]">
              {renderStep()}
            </div>
          </CardContent>
        </Card>

        {currentStep === steps.length - 1 && (
          <Card className="mb-6 border-primary/30 bg-primary/5">
            <CardContent className="p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">Your estimated rating</p>
                  <p className="text-2xl font-bold text-primary">{calculatedRating.toFixed(1)}</p>
                </div>
                <div className="text-right">
                  <p className="text-xs text-muted-foreground">Scale: 1.0 - 7.0</p>
                  <p className="text-sm">
                    {calculatedRating < 2.5 && "Beginner"}
                    {calculatedRating >= 2.5 && calculatedRating < 4 && "Intermediate"}
                    {calculatedRating >= 4 && calculatedRating < 5.5 && "Advanced"}
                    {calculatedRating >= 5.5 && "Elite"}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="flex gap-3">
          <Button
            variant="outline"
            onClick={handleBack}
            disabled={currentStep === 0}
            className="flex-1"
            data-testid="button-back"
          >
            <ChevronLeft className="w-4 h-4 mr-2" />
            Back
          </Button>
          <Button
            onClick={handleNext}
            disabled={saveOnboardingMutation.isPending}
            className="flex-1"
            data-testid="button-next"
          >
            {currentStep === steps.length - 1 ? (
              saveOnboardingMutation.isPending ? "Saving..." : "Complete"
            ) : (
              <>
                Next
                <ChevronRight className="w-4 h-4 ml-2" />
              </>
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}
