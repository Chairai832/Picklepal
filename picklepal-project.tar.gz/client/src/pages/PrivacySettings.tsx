import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Separator } from "@/components/ui/separator";
import { 
  ChevronLeft, ChevronRight, Lock, UserX, MapPin
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";



export default function PrivacySettings() {
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const [settings, setSettings] = useState({
    privateAccount: false,
    locationTracking: true,
  });

  const handleToggle = (key: keyof typeof settings) => {
    setSettings(prev => {
      const newSettings = { ...prev, [key]: !prev[key] };
      toast({ title: `${key === 'privateAccount' ? 'Private account' : 'Location tracking'} ${newSettings[key] ? 'enabled' : 'disabled'}` });
      return newSettings;
    });
  };

  return (
    <div className="container mx-auto px-4 py-6 pb-24 max-w-lg">
      <div className="flex items-center gap-3 mb-6">
        <Button variant="ghost" size="icon" onClick={() => navigate("/settings")} data-testid="button-back">
          <ChevronLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-2xl font-display font-bold">Privacy Settings</h1>
      </div>

      <div className="bg-card border border-border rounded-xl overflow-hidden">
        <div className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Lock className="w-5 h-5 text-muted-foreground" />
              <div>
                <div className="font-medium">Private Account</div>
                <p className="text-sm text-muted-foreground">
                  Others can't see your content or interact with you
                </p>
              </div>
            </div>
            <Switch 
              checked={settings.privateAccount}
              onCheckedChange={() => handleToggle('privateAccount')}
              data-testid="switch-private-account"
            />
          </div>
        </div>

        <Separator />

        <div 
          className="flex items-center justify-between p-4 hover-elevate cursor-pointer"
          onClick={() => toast({ title: "Blocked accounts", description: "No blocked accounts yet" })}
          data-testid="menu-blocked-accounts"
        >
          <div className="flex items-center gap-3">
            <UserX className="w-5 h-5 text-muted-foreground" />
            <div>
              <div className="font-medium">Blocked Accounts</div>
              <p className="text-sm text-muted-foreground">
                No blocked accounts
              </p>
            </div>
          </div>
          <ChevronRight className="w-4 h-4 text-muted-foreground" />
        </div>

        <Separator />

        <div className="p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <MapPin className="w-5 h-5 text-muted-foreground" />
              <div>
                <div className="font-medium">Location</div>
                <p className="text-sm text-muted-foreground">
                  Track your approximate location for nearby courts
                </p>
              </div>
            </div>
            <Switch 
              checked={settings.locationTracking}
              onCheckedChange={() => handleToggle('locationTracking')}
              data-testid="switch-location"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
