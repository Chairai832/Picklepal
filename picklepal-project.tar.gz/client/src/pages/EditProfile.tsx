import { useState, useRef } from "react";
import { useAuth } from "@/hooks/use-auth";
import { useProfile } from "@/hooks/use-profile";
import { useLocation } from "wouter";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Separator } from "@/components/ui/separator";
import { ChevronLeft, Camera, Hand, Target, Gamepad2 } from "lucide-react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function EditProfile() {
  const { user } = useAuth();
  const { data: profile } = useProfile();
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);

  const [formData, setFormData] = useState({
    firstName: user?.firstName || "",
    lastName: user?.lastName || "",
    email: user?.email || "",
    phone: "",
    gender: "",
    dateOfBirth: "",
    location: profile?.location || "",
    preferredHand: profile?.preferredHand || "right",
    courtPosition: profile?.courtPosition || "both",
    matchType: profile?.matchType || "doubles",
  });

  const updateProfileMutation = useMutation({
    mutationFn: async (data: any) => {
      return await apiRequest("PATCH", "/api/profiles/me", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profiles/me"] });
      toast({ title: "Profile updated successfully!" });
    },
    onError: (err: Error) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const handleSave = () => {
    updateProfileMutation.mutate({
      location: formData.location,
      preferredHand: formData.preferredHand,
      courtPosition: formData.courtPosition,
      matchType: formData.matchType,
    });
  };

  const handleImageClick = () => {
    fileInputRef.current?.click();
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      toast({ title: "Profile picture upload coming soon!" });
    }
  };

  if (!user) return null;

  return (
    <div className="container mx-auto px-4 py-6 pb-24 max-w-lg">
      <div className="flex items-center gap-3 mb-6">
        <Button variant="ghost" size="icon" onClick={() => navigate("/settings")} data-testid="button-back">
          <ChevronLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-2xl font-display font-bold">Edit Profile</h1>
      </div>

      <div className="flex flex-col items-center mb-8">
        <div className="relative" onClick={handleImageClick}>
          <Avatar className="w-24 h-24 border-4 border-primary/20 cursor-pointer">
            <AvatarImage src={user.profileImageUrl || undefined} />
            <AvatarFallback className="text-2xl font-bold bg-primary/10 text-primary">
              {user.firstName?.[0]}{user.lastName?.[0]}
            </AvatarFallback>
          </Avatar>
          <div className="absolute bottom-0 right-0 bg-primary rounded-full p-2 cursor-pointer shadow-lg">
            <Camera className="w-4 h-4 text-primary-foreground" />
          </div>
        </div>
        <input 
          ref={fileInputRef}
          type="file" 
          accept="image/*" 
          className="hidden" 
          onChange={handleImageChange}
          data-testid="input-profile-image"
        />
        <button 
          className="text-primary text-sm font-medium mt-2"
          onClick={handleImageClick}
          data-testid="button-change-photo"
        >
          Change Photo
        </button>
      </div>

      <div className="space-y-6">
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="firstName">First Name</Label>
              <Input 
                id="firstName"
                value={formData.firstName}
                disabled
                className="bg-muted"
                data-testid="input-first-name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="lastName">Last Name</Label>
              <Input 
                id="lastName"
                value={formData.lastName}
                disabled
                className="bg-muted"
                data-testid="input-last-name"
              />
            </div>
          </div>
          <p className="text-xs text-muted-foreground">Name is managed by your Replit account</p>

          <div className="space-y-2">
            <Label htmlFor="email">Email</Label>
            <Input 
              id="email"
              type="email"
              value={formData.email}
              disabled
              className="bg-muted"
              data-testid="input-email"
            />
            <p className="text-xs text-muted-foreground">Email is managed by Replit</p>
          </div>

          <div className="space-y-2">
            <Label htmlFor="location">Where do you play?</Label>
            <Input 
              id="location"
              placeholder="City, State"
              value={formData.location}
              onChange={(e) => setFormData({ ...formData, location: e.target.value })}
              data-testid="input-location"
            />
          </div>
        </div>

        <Separator />

        <div className="space-y-4">
          <h3 className="font-semibold">Player Preferences</h3>
          
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Hand className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm">Preferred Hand</span>
            </div>
            <Select 
              value={formData.preferredHand} 
              onValueChange={(value) => setFormData({ ...formData, preferredHand: value })}
            >
              <SelectTrigger className="w-28" data-testid="select-preferred-hand">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="left">Left</SelectItem>
                <SelectItem value="right">Right</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm">Court Position</span>
            </div>
            <Select 
              value={formData.courtPosition} 
              onValueChange={(value) => setFormData({ ...formData, courtPosition: value })}
            >
              <SelectTrigger className="w-28" data-testid="select-court-position">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="left">Left Side</SelectItem>
                <SelectItem value="right">Right Side</SelectItem>
                <SelectItem value="both">Both</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Gamepad2 className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm">Match Type</span>
            </div>
            <Select 
              value={formData.matchType} 
              onValueChange={(value) => setFormData({ ...formData, matchType: value })}
            >
              <SelectTrigger className="w-28" data-testid="select-match-type">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="singles">Singles</SelectItem>
                <SelectItem value="doubles">Doubles</SelectItem>
                <SelectItem value="both">Both</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <Button 
          className="w-full"
          onClick={handleSave}
          disabled={updateProfileMutation.isPending}
          data-testid="button-save-profile"
        >
          {updateProfileMutation.isPending ? "Saving..." : "Save Changes"}
        </Button>
      </div>
    </div>
  );
}
