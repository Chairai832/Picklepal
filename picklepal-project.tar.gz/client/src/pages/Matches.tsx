import { useState, useMemo } from "react";
import { useMatches } from "@/hooks/use-matches";
import { MatchCard } from "@/components/MatchCard";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { CreateMatchDialog } from "@/components/CreateMatchDialog";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Filter, Calendar, MapPin } from "lucide-react";

export default function Matches() {
  const { data: matches, isLoading } = useMatches();
  
  const [filterCity, setFilterCity] = useState<string>("all");
  const [filterDate, setFilterDate] = useState<string>("");
  const [openOnly, setOpenOnly] = useState(true);
  const [showPast, setShowPast] = useState(false);

  const cities = useMemo(() => {
    if (!matches) return [];
    const citySet = new Set(matches.map((m: any) => m.city || m.court?.venue?.city).filter(Boolean));
    return Array.from(citySet) as string[];
  }, [matches]);

  const filteredMatches = useMemo(() => {
    if (!matches) return [];
    
    return matches
      .filter((m: any) => {
        const matchCity = m.city || m.court?.venue?.city;
        if (filterCity !== "all" && matchCity !== filterCity) return false;
        return true;
      })
      .filter((m: any) => {
        if (!filterDate) return true;
        const matchDate = new Date(m.date || m.startsAt).toISOString().slice(0, 10);
        return matchDate === filterDate;
      })
      .filter((m: any) => {
        if (showPast) return true;
        const matchDate = new Date(m.date || m.startsAt);
        return matchDate.getTime() >= Date.now();
      })
      .filter((m: any) => {
        if (!openOnly) return true;
        const playerCount = m.players?.length || 0;
        const maxPlayers = m.maxPlayers || 4;
        return playerCount < maxPlayers && m.status === "scheduled";
      })
      .sort((a: any, b: any) => {
        const dateA = new Date(a.date || a.startsAt).getTime();
        const dateB = new Date(b.date || b.startsAt).getTime();
        return dateA - dateB;
      });
  }, [matches, filterCity, filterDate, openOnly, showPast]);

  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      <div className="flex justify-between items-end gap-4 flex-wrap">
        <div className="space-y-2">
          <h1 className="text-3xl font-display font-bold">Community Matches</h1>
          <p className="text-muted-foreground">Find games fast. Create a match, share it, and play.</p>
        </div>
        <CreateMatchDialog>
          <Button size="sm" className="md:size-default font-bold shadow-lg shadow-primary/20">
            <Plus className="w-4 h-4 md:mr-2" /> 
            <span className="hidden md:inline">Create Match</span>
          </Button>
        </CreateMatchDialog>
      </div>

      <div className="bg-card border border-border rounded-xl p-4">
        <div className="flex items-center gap-2 mb-3">
          <Filter className="w-4 h-4 text-muted-foreground" />
          <span className="text-sm font-medium">Filters</span>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">
              <MapPin className="w-3 h-3 inline mr-1" />City
            </label>
            <Select value={filterCity} onValueChange={setFilterCity}>
              <SelectTrigger className="h-9" data-testid="select-filter-city">
                <SelectValue placeholder="All cities" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Cities</SelectItem>
                {cities.map(city => (
                  <SelectItem key={city} value={city}>{city}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div>
            <label className="text-xs text-muted-foreground mb-1 block">
              <Calendar className="w-3 h-3 inline mr-1" />Date
            </label>
            <Input 
              type="date" 
              value={filterDate}
              onChange={(e) => setFilterDate(e.target.value)}
              className="h-9"
              data-testid="input-filter-date"
            />
          </div>
          
          <div className="flex items-end">
            <Button 
              variant={openOnly ? "default" : "outline"}
              size="sm"
              className="w-full"
              onClick={() => setOpenOnly(!openOnly)}
              data-testid="button-filter-open"
            >
              {openOnly ? "Open Only" : "All Matches"}
            </Button>
          </div>
          
          <div className="flex items-end">
            <Button 
              variant={showPast ? "secondary" : "outline"}
              size="sm"
              className="w-full"
              onClick={() => setShowPast(!showPast)}
              data-testid="button-filter-past"
            >
              {showPast ? "Showing Past" : "Hide Past"}
            </Button>
          </div>
        </div>
      </div>

      {isLoading ? (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[1, 2, 3, 4, 5, 6].map(i => <Skeleton key={i} className="h-64 rounded-2xl" />)}
        </div>
      ) : filteredMatches.length === 0 ? (
        <div className="text-center py-20 bg-muted/20 rounded-3xl border border-dashed border-border">
          <h3 className="text-xl font-bold mb-2">No matches found</h3>
          <p className="text-muted-foreground mb-6">Try changing filters or create a match and share it!</p>
          <CreateMatchDialog>
            <Button>Create Match</Button>
          </CreateMatchDialog>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredMatches.map((match: any) => (
            <MatchCard key={match.id} match={match} />
          ))}
        </div>
      )}
    </div>
  );
}
