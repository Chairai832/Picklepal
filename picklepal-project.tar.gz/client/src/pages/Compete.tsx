import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Trophy, Medal, Calendar } from "lucide-react";

export default function Compete() {
  return (
    <div className="container mx-auto px-4 py-6 space-y-6">
      <div>
        <h1 className="text-3xl font-display font-bold">Compete</h1>
        <p className="text-muted-foreground mt-1">Join tournaments and leagues</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Card className="border-border/50">
          <CardHeader className="flex flex-row items-center gap-3 space-y-0">
            <div className="p-2 rounded-lg bg-amber-500/10">
              <Trophy className="w-5 h-5 text-amber-500" />
            </div>
            <CardTitle className="text-lg">Tournaments</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground text-sm mb-4">
              Compete in local and regional tournaments
            </p>
            <div className="text-center py-8 bg-muted/30 rounded-lg">
              <p className="text-muted-foreground text-sm">Coming soon</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50">
          <CardHeader className="flex flex-row items-center gap-3 space-y-0">
            <div className="p-2 rounded-lg bg-blue-500/10">
              <Medal className="w-5 h-5 text-blue-500" />
            </div>
            <CardTitle className="text-lg">Leagues</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground text-sm mb-4">
              Join seasonal leagues and climb the rankings
            </p>
            <div className="text-center py-8 bg-muted/30 rounded-lg">
              <p className="text-muted-foreground text-sm">Coming soon</p>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/50 md:col-span-2">
          <CardHeader className="flex flex-row items-center gap-3 space-y-0">
            <div className="p-2 rounded-lg bg-primary/10">
              <Calendar className="w-5 h-5 text-primary" />
            </div>
            <CardTitle className="text-lg">Upcoming Events</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-center py-12 bg-muted/30 rounded-lg">
              <p className="text-muted-foreground">No upcoming events</p>
              <p className="text-muted-foreground text-sm mt-2">Check back soon for tournaments and leagues in your area</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
