import { useAuth } from "@/hooks/use-auth";
import { useProfile } from "@/hooks/use-profile";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Separator } from "@/components/ui/separator";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { 
  Building2, Users, TrendingUp, Trophy, Hand, Target, 
  Gamepad2, Menu, ChevronRight, Camera
} from "lucide-react";
import { Link } from "wouter";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

export default function Profile() {
  const { user, logout } = useAuth();
  const { data: profile } = useProfile();

  const { data: followerStats } = useQuery<{ followers: number; following: number }>({
    queryKey: [`/api/followers/stats/${user?.id}`],
    enabled: !!user?.id,
  });

  const { data: ratingHistoryData } = useQuery<{ rating: number; recordedAt: string }[]>({
    queryKey: [`/api/ratings/history/${user?.id}`],
    enabled: !!user?.id,
  });

  type RecentMatch = {
    id: number;
    title: string;
    startsAt: string;
    city: string;
    venueName: string;
    courtName: string;
    team: string;
    competitive: boolean;
    outcome: string;
  };
  
  const { data: myMatchesData } = useQuery<{ 
    stats: { wins: number; losses: number; ties: number; total: number };
    recentMatches: RecentMatch[];
  }>({
    queryKey: ["/api/me/matches"],
    enabled: !!user?.id,
  });

  const { toast } = useToast();

  const switchRoleMutation = useMutation({
    mutationFn: async (newRole: "player" | "venue") => {
      return await apiRequest("PATCH", "/api/users/role", { role: newRole });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/auth/user"] });
      toast({ title: "Role switched successfully!" });
    },
    onError: (err: Error) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  const updatePreferenceMutation = useMutation({
    mutationFn: async (data: { preferredHand?: string; courtPosition?: string; matchType?: string }) => {
      return await apiRequest("PATCH", "/api/profiles/me", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/profiles/me"] });
      toast({ title: "Preference updated!" });
    },
    onError: (err: Error) => {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    },
  });

  if (!user) return null;

  const rating = profile?.rating || 3.0;
  const ratingReliability = profile?.ratingReliability || 0;
  const matchesPlayed = myMatchesData?.stats.total || profile?.matchesPlayed || 0;
  const matchesWon = myMatchesData?.stats.wins || profile?.matchesWon || 0;
  const matchesLost = myMatchesData?.stats.losses || 0;
  const matchesTied = myMatchesData?.stats.ties || 0;
  const winRate = matchesPlayed > 0 ? Math.round((matchesWon / matchesPlayed) * 100) : 0;
  const recentMatches = myMatchesData?.recentMatches || [];

  const ratingData = ratingHistoryData && ratingHistoryData.length > 0
    ? ratingHistoryData.slice(-6).map((r, idx) => ({
        month: new Date(r.recordedAt).toLocaleDateString('en-US', { month: 'short' }),
        rating: r.rating,
      }))
    : [
        { month: "Jan", rating: 2.8 },
        { month: "Feb", rating: 2.9 },
        { month: "Mar", rating: 3.1 },
        { month: "Apr", rating: 3.0 },
        { month: "May", rating: 3.2 },
        { month: "Jun", rating: rating },
      ];

  const maxRating = 7.0;
  const minRating = 1.0;
  const ratingRange = maxRating - minRating;

  return (
    <div className="container mx-auto px-4 py-6 pb-24 space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-display font-bold">Profile</h1>
        <Link href="/settings">
          <Button variant="ghost" size="icon" data-testid="button-settings">
            <Menu className="w-5 h-5" />
          </Button>
        </Link>
      </div>

      <div className="flex items-center gap-6">
        <Link href="/settings/edit-profile">
          <div className="relative cursor-pointer group">
            <Avatar className="w-20 h-20 md:w-24 md:h-24 border-4 border-primary/20">
              <AvatarImage src={user.profileImageUrl || undefined} />
              <AvatarFallback className="text-2xl font-bold bg-primary/10 text-primary">
                {user.firstName?.[0]}{user.lastName?.[0]}
              </AvatarFallback>
            </Avatar>
            <div className="absolute bottom-0 right-0 bg-primary rounded-full p-1.5 shadow-lg group-hover:scale-110 transition-transform">
              <Camera className="w-3 h-3 text-primary-foreground" />
            </div>
          </div>
        </Link>
        
        <div className="flex-1 grid grid-cols-3 gap-2 text-center">
          <div className="cursor-pointer" data-testid="stat-matches">
            <div className="text-xl font-bold">{matchesPlayed}</div>
            <div className="text-xs text-muted-foreground">Matches</div>
          </div>
          <div className="cursor-pointer" data-testid="stat-followers">
            <div className="text-xl font-bold">{followerStats?.followers || 0}</div>
            <div className="text-xs text-muted-foreground">Followers</div>
          </div>
          <div className="cursor-pointer" data-testid="stat-following">
            <div className="text-xl font-bold">{followerStats?.following || 0}</div>
            <div className="text-xs text-muted-foreground">Following</div>
          </div>
        </div>
      </div>

      <div>
        <h2 className="font-bold text-lg">{user.firstName} {user.lastName}</h2>
        <p className="text-muted-foreground text-sm">{profile?.bio || profile?.location || "Pickleball enthusiast"}</p>
      </div>

      <div className="flex gap-2 flex-wrap">
        <Link href="/settings/edit-profile" className="flex-1">
          <Button variant="outline" size="sm" className="w-full" data-testid="button-edit-profile">
            Edit Profile
          </Button>
        </Link>
        {user.role === "player" ? (
          <Button 
            variant="secondary" 
            size="sm"
            className="flex-1"
            onClick={() => switchRoleMutation.mutate("venue")}
            disabled={switchRoleMutation.isPending}
            data-testid="button-switch-to-venue"
          >
            <Building2 className="w-4 h-4 mr-2" /> Venue Mode
          </Button>
        ) : (
          <Button 
            variant="secondary" 
            size="sm"
            className="flex-1"
            onClick={() => switchRoleMutation.mutate("player")}
            disabled={switchRoleMutation.isPending}
            data-testid="button-switch-to-player"
          >
            <Users className="w-4 h-4 mr-2" /> Player Mode
          </Button>
        )}
      </div>

      <Separator />

      <Card className="border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Trophy className="w-4 h-4 text-primary" />
            Level & Rating
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-3xl font-bold text-primary">{rating.toFixed(1)}</div>
              <div className="text-xs text-muted-foreground">Rating</div>
            </div>
            <div className="text-right">
              <div className="flex items-center gap-2">
                <span className="text-sm text-muted-foreground">Reliability</span>
                <Badge variant={ratingReliability >= 70 ? "default" : "secondary"}>
                  {ratingReliability}%
                </Badge>
              </div>
              <Progress value={ratingReliability} className="w-24 h-2 mt-1" />
            </div>
          </div>
          <div className="text-xs text-muted-foreground">
            {ratingReliability < 30 && "Play more matches to establish your rating reliability"}
            {ratingReliability >= 30 && ratingReliability < 70 && "Your rating is becoming more reliable"}
            {ratingReliability >= 70 && "Your rating is well established"}
          </div>
        </CardContent>
      </Card>

      <Card className="border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-primary" />
            Rating Progression
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-32 flex items-end justify-between gap-1">
            {ratingData.map((data, idx) => {
              const heightPct = ((data.rating - minRating) / ratingRange) * 100;
              return (
                <div key={idx} className="flex-1 flex flex-col items-center gap-1">
                  <div 
                    className="w-full bg-primary/20 rounded-t relative"
                    style={{ height: `${heightPct}%` }}
                  >
                    <div 
                      className="absolute inset-0 bg-primary rounded-t"
                      style={{ 
                        opacity: idx === ratingData.length - 1 ? 1 : 0.5 
                      }}
                    />
                  </div>
                  <span className="text-[10px] text-muted-foreground">{data.month}</span>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <Card className="border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Match Stats</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-4 gap-4 text-center">
            <div>
              <div className="text-2xl font-bold">{matchesPlayed}</div>
              <div className="text-xs text-muted-foreground">Played</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-green-500">{matchesWon}</div>
              <div className="text-xs text-muted-foreground">Won</div>
            </div>
            <div>
              <div className="text-2xl font-bold text-red-500">{matchesLost}</div>
              <div className="text-xs text-muted-foreground">Lost</div>
            </div>
            <div>
              <div className="text-2xl font-bold">{winRate}%</div>
              <div className="text-xs text-muted-foreground">Win Rate</div>
            </div>
          </div>
          <div className="mt-3 text-center">
            <Badge variant="secondary" className="text-sm">
              Record: {matchesWon}-{matchesLost}-{matchesTied}
            </Badge>
          </div>
        </CardContent>
      </Card>

      <Card className="border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Player Preferences</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Hand className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm">Preferred Hand</span>
            </div>
            <Select
              value={profile?.preferredHand || "right"}
              onValueChange={(value) => updatePreferenceMutation.mutate({ preferredHand: value })}
              disabled={updatePreferenceMutation.isPending}
            >
              <SelectTrigger className="w-28" data-testid="select-preferred-hand">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="left">Left</SelectItem>
                <SelectItem value="right">Right</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Target className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm">Court Position</span>
            </div>
            <Select
              value={profile?.courtPosition || "both"}
              onValueChange={(value) => updatePreferenceMutation.mutate({ courtPosition: value })}
              disabled={updatePreferenceMutation.isPending}
            >
              <SelectTrigger className="w-28" data-testid="select-court-position">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="forehand">Forehand</SelectItem>
                <SelectItem value="backhand">Backhand</SelectItem>
                <SelectItem value="both">Both</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center justify-between gap-4">
            <div className="flex items-center gap-2">
              <Gamepad2 className="w-4 h-4 text-muted-foreground" />
              <span className="text-sm">Match Type</span>
            </div>
            <Select
              value={profile?.matchType || "doubles"}
              onValueChange={(value) => updatePreferenceMutation.mutate({ matchType: value })}
              disabled={updatePreferenceMutation.isPending}
            >
              <SelectTrigger className="w-28" data-testid="select-match-type">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="singles">Singles</SelectItem>
                <SelectItem value="doubles">Doubles</SelectItem>
                <SelectItem value="both">Both</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card className="border-border/50">
        <CardHeader className="pb-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Trophy className="w-4 h-4 text-primary" />
            Recent Competitive Matches
          </CardTitle>
        </CardHeader>
        <CardContent>
          {recentMatches.length === 0 ? (
            <div className="text-center py-6 text-muted-foreground text-sm">
              No finalized matches yet. Join or create a competitive match.
            </div>
          ) : (
            <div className="space-y-3">
              {recentMatches.slice(0, 5).map((m) => (
                <div key={m.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/30">
                  <div className="flex-1">
                    <div className="font-medium text-sm">{m.title}</div>
                    <div className="text-xs text-muted-foreground">
                      {m.city} • {m.venueName} • {m.courtName}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {new Date(m.startsAt).toLocaleDateString()} • Team {m.team}
                    </div>
                  </div>
                  <Badge 
                    variant={m.outcome === "win" ? "default" : m.outcome === "loss" ? "destructive" : "secondary"}
                    className="ml-2"
                  >
                    {m.outcome.toUpperCase()}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card className="border-border/50">
        <CardHeader className="pb-2 flex flex-row items-center justify-between gap-2">
          <CardTitle className="text-base flex items-center gap-2">
            <Users className="w-4 h-4 text-primary" />
            Frequent Partners
          </CardTitle>
          <ChevronRight className="w-4 h-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-center py-6 text-muted-foreground text-sm">
            Play more matches to see your frequent partners
          </div>
        </CardContent>
      </Card>

      <Card className="border-border/50">
        <CardHeader className="pb-2 flex flex-row items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Building2 className="w-4 h-4 text-primary" />
            My Clubs
          </CardTitle>
          <ChevronRight className="w-4 h-4 text-muted-foreground" />
        </CardHeader>
        <CardContent>
          <div className="text-center py-6 text-muted-foreground text-sm">
            You haven't joined any clubs yet
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
