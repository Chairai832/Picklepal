import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ArrowRight, Trophy, Users, Zap } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Navbar */}
      <nav className="border-b border-border/40 bg-background/80 backdrop-blur-md sticky top-0 z-50">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-full bg-primary flex items-center justify-center">
              <span className="font-bold text-primary-foreground">P</span>
            </div>
            <span className="font-display font-bold text-xl tracking-tight">PicklePal</span>
          </div>
          <div className="flex items-center gap-2">
            <Button asChild variant="ghost" className="font-semibold">
              <a href="/api/login">Log In</a>
            </Button>
            <Button asChild className="font-semibold">
              <a href="/api/login">Sign Up</a>
            </Button>
          </div>
        </div>
      </nav>

      <main className="flex-1">
        {/* Hero Section */}
        <div className="relative overflow-hidden py-20 lg:py-32">
          <div className="container mx-auto px-4 relative z-10">
            <div className="max-w-3xl">
              <h1 className="font-display font-bold text-5xl md:text-7xl leading-tight mb-6 tracking-tight">
                Play more <br/>
                <span className="text-primary">Pickleball.</span>
              </h1>
              <p className="text-lg md:text-xl text-muted-foreground mb-8 max-w-xl leading-relaxed">
                Join the fastest growing community. Find courts, book matches, and meet players at your level. The court is calling.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button asChild size="lg" className="text-lg font-bold h-12 px-8 shadow-xl shadow-primary/20 hover:shadow-primary/40 transition-all hover:-translate-y-1">
                  <a href="/api/login">
                    Create Free Account <ArrowRight className="ml-2 w-5 h-5" />
                  </a>
                </Button>
                <Button asChild size="lg" variant="outline" className="text-lg h-12 px-8">
                  <Link href="/venues">
                    Browse Courts
                  </Link>
                </Button>
              </div>
              <p className="text-sm text-muted-foreground mt-4">
                Already have an account? <a href="/api/login" className="text-primary hover:underline font-medium">Log in</a>
              </p>
            </div>
          </div>
          
          {/* Abstract blobs */}
          <div className="absolute top-0 right-0 -translate-y-1/4 translate-x-1/4 w-[800px] h-[800px] bg-primary/10 rounded-full blur-3xl -z-10" />
          <div className="absolute bottom-0 left-0 translate-y-1/4 -translate-x-1/4 w-[600px] h-[600px] bg-secondary/5 rounded-full blur-3xl -z-10" />
        </div>

        {/* Features Grid */}
        <section className="py-24 bg-card border-y border-border/50">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-3 gap-12">
              <div className="space-y-4">
                <div className="w-12 h-12 rounded-2xl bg-primary/10 flex items-center justify-center">
                  <Zap className="w-6 h-6 text-primary" />
                </div>
                <h3 className="font-display font-bold text-2xl">Instant Booking</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Find available courts near you and book them instantly. No more phone calls or waiting lists.
                </p>
              </div>
              <div className="space-y-4">
                <div className="w-12 h-12 rounded-2xl bg-secondary/10 flex items-center justify-center">
                  <Users className="w-6 h-6 text-secondary" />
                </div>
                <h3 className="font-display font-bold text-2xl">Find Players</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Connect with players at your skill level. Join open matches or create your own community.
                </p>
              </div>
              <div className="space-y-4">
                <div className="w-12 h-12 rounded-2xl bg-orange-500/10 flex items-center justify-center">
                  <Trophy className="w-6 h-6 text-orange-500" />
                </div>
                <h3 className="font-display font-bold text-2xl">Track Progress</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Record your matches, track your stats, and watch your level improve over time.
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      <footer className="py-8 border-t border-border">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          © {new Date().getFullYear()} PicklePal. All rights reserved.
        </div>
      </footer>
    </div>
  );
}
