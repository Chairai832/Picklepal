import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  ChevronLeft, Send, Bot, User
} from "lucide-react";

type Message = {
  id: number;
  role: "user" | "assistant";
  content: string;
};

export default function HelpPage() {
  const [, navigate] = useLocation();
  const [input, setInput] = useState("");
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 1,
      role: "assistant",
      content: "Hi! I'm your PicklePal assistant. How can I help you today? You can ask me about:\n\n• Finding and booking courts\n• Creating or joining matches\n• Understanding your rating\n• Using app features\n• Account settings"
    }
  ]);

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage: Message = {
      id: messages.length + 1,
      role: "user",
      content: input
    };

    setMessages(prev => [...prev, userMessage]);
    setInput("");

    setTimeout(() => {
      const responses: Record<string, string> = {
        default: "Thanks for your question! Our team is working on AI-powered help. For now, you can explore the app or contact support at help@picklepal.app",
        book: "To book a court:\n1. Go to 'Venues' tab\n2. Select a venue near you\n3. Choose an available time slot\n4. Confirm your booking",
        match: "To join or create a match:\n1. Go to 'Find Matches'\n2. Browse open matches or tap 'Create Match'\n3. Set your preferences\n4. Share with friends via WhatsApp",
        rating: "Your rating is calculated based on:\n• Match outcomes (wins/losses)\n• Opponent skill levels\n• Rating reliability increases with more matches",
      };

      const lowerInput = input.toLowerCase();
      let response = responses.default;
      if (lowerInput.includes("book") || lowerInput.includes("court")) response = responses.book;
      if (lowerInput.includes("match") || lowerInput.includes("join") || lowerInput.includes("create")) response = responses.match;
      if (lowerInput.includes("rating") || lowerInput.includes("level") || lowerInput.includes("score")) response = responses.rating;

      const assistantMessage: Message = {
        id: messages.length + 2,
        role: "assistant",
        content: response
      };
      setMessages(prev => [...prev, assistantMessage]);
    }, 1000);
  };

  return (
    <div className="container mx-auto px-4 py-6 pb-24 max-w-lg h-[calc(100vh-6rem)] flex flex-col">
      <div className="flex items-center gap-3 mb-4">
        <Button variant="ghost" size="icon" onClick={() => navigate("/settings")} data-testid="button-back">
          <ChevronLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-2xl font-display font-bold">Help</h1>
      </div>

      <Card className="flex-1 flex flex-col overflow-hidden">
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <div 
                key={message.id}
                className={`flex gap-3 ${message.role === "user" ? "justify-end" : "justify-start"}`}
              >
                {message.role === "assistant" && (
                  <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                    <Bot className="w-4 h-4 text-primary" />
                  </div>
                )}
                <div 
                  className={`rounded-2xl px-4 py-2 max-w-[80%] whitespace-pre-wrap ${
                    message.role === "user" 
                      ? "bg-primary text-primary-foreground" 
                      : "bg-muted"
                  }`}
                >
                  {message.content}
                </div>
                {message.role === "user" && (
                  <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            ))}
          </div>
        </ScrollArea>
        <CardContent className="border-t p-4">
          <div className="flex gap-2">
            <Input 
              placeholder="Ask a question..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleSend()}
              data-testid="input-help-message"
            />
            <Button size="icon" onClick={handleSend} data-testid="button-send-help">
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
