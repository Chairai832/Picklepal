import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { ChevronLeft } from "lucide-react";

export default function PrivacyPolicy() {
  const [, navigate] = useLocation();

  return (
    <div className="container mx-auto px-4 py-6 pb-24 max-w-lg">
      <div className="flex items-center gap-3 mb-6">
        <Button variant="ghost" size="icon" onClick={() => navigate("/settings")} data-testid="button-back">
          <ChevronLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-2xl font-display font-bold">Privacy Policy</h1>
      </div>

      <div className="prose prose-sm dark:prose-invert max-w-none">
        <p className="text-muted-foreground">Last updated: February 2026</p>

        <h2 className="text-lg font-semibold mt-6">1. Information We Collect</h2>
        <p className="text-muted-foreground">
          We collect information you provide directly, such as your name, email, and profile details. We also collect usage data to improve our services.
        </p>

        <h2 className="text-lg font-semibold mt-6">2. How We Use Your Information</h2>
        <p className="text-muted-foreground">
          We use your information to provide and improve our services, process bookings, communicate with you, and personalize your experience.
        </p>

        <h2 className="text-lg font-semibold mt-6">3. Information Sharing</h2>
        <p className="text-muted-foreground">
          We do not sell your personal information. We may share information with venue partners to facilitate bookings and with service providers who assist our operations.
        </p>

        <h2 className="text-lg font-semibold mt-6">4. Location Data</h2>
        <p className="text-muted-foreground">
          With your permission, we collect approximate location data to show you nearby courts and matches. You can disable location tracking in your settings.
        </p>

        <h2 className="text-lg font-semibold mt-6">5. Data Security</h2>
        <p className="text-muted-foreground">
          We implement industry-standard security measures to protect your personal information. However, no method of transmission over the Internet is 100% secure.
        </p>

        <h2 className="text-lg font-semibold mt-6">6. Your Rights</h2>
        <p className="text-muted-foreground">
          You have the right to access, correct, or delete your personal information. You can also request a copy of your data or opt out of marketing communications.
        </p>

        <h2 className="text-lg font-semibold mt-6">7. Contact Us</h2>
        <p className="text-muted-foreground">
          If you have questions about this Privacy Policy, please contact us at privacy@picklepal.app
        </p>
      </div>
    </div>
  );
}
